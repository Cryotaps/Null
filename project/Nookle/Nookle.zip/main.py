import discord
import os
from discord.ext import tasks

os.system("python -m pip install -r requirements.txt")
import datetime
import re
import asyncio
import sqlite3
from threading import Thread
from sqlite3 import Error
import random
import pyshorteners
import requests
from googletrans import Translator
import json
import qrcode
from bs4 import BeautifulSoup
import lyricsgenius

intents = discord.Intents.all()
intents.message_content = True
client = discord.Client(intents=intents)

genius = lyricsgenius.Genius(
    "id11XydEhsueoeGbeaWPUG2ah1MuxYie5Nsh7FhFUjQpF3kA4s52hhtGHmXLIMu2"
)

playing_players = set()

game_states = {}

global dondgame_active
dondgame_active = False
dondgame_initiator = None
user_case = None
cases = list(range(1, 27))

translator = Translator()

# Initialize SQLite database

conn = sqlite3.connect("cookie_clicker.db")
cursor = conn.cursor()
cursor.execute(
    "CREATE TABLE IF NOT EXISTS cookies (user_id INTEGER PRIMARY KEY, cookies INTEGER DEFAULT 0)"
)
conn.commit()
# Connect to the database

conn = sqlite3.connect("bot.sql")
c = conn.cursor()
# Create the table if it doesn't exist

c.execute("""CREATE TABLE IF NOT EXISTS botchan
             (id INTEGER PRIMARY KEY, channel INTEGER)""")
conn.commit()
# Connect to the database

conn = sqlite3.connect("bot.sql")
c = conn.cursor()
# Create the table if it doesn't exist

c.execute("""CREATE TABLE IF NOT EXISTS discord
             (id INTEGER PRIMARY KEY, channel INTEGER)""")
conn.commit()
# Function to get the channel ID from the database


def get_channel_id(discord_id):
    c.execute("SELECT channel FROM discord where id = ?", (discord_id,))
    result = c.fetchone()
    if result:
        return result[0]
    else:
        return False


def get_botchannel_id(discord_id):
    c.execute("SELECT channel FROM botchan where id = ?", (discord_id,))
    result = c.fetchone()
    if result:
        return result[0]
    else:
        return False


conn = sqlite3.connect("bot.sql")
c = conn.cursor()
# Create the table if it doesn't exist

c.execute("""CREATE TABLE IF NOT EXISTS blacklistedWords
             (discordid INTEGER PRIMARY KEY, words TEXT)""")
conn.commit()


async def is_blacklisted_word(message):
    server_id = message.guild.id
    content_lower = message.content.lower()
    blacklisted_words = get_blacklisted_words(server_id)

    for word in blacklisted_words:
        if contains_word(content_lower, word.lower()):
            return True
    return False


def add_blacklisted_word(server_id, word):
    conn = sqlite3.connect("bot.sql")
    c = conn.cursor()

    # Normalize the word (convert to lowercase and remove leading/trailing spaces)

    normalized_word = word.lower().strip()

    # Check if discordid already exists

    c.execute("SELECT * FROM blacklistedWords WHERE discordid=?", (server_id,))
    existing_record = c.fetchone()

    if existing_record:
        # Update the existing record by appending the new word

        updated_words = existing_record[1] + ", " + normalized_word
        c.execute(
            "UPDATE blacklistedWords SET words=? WHERE discordid=?",
            (updated_words, server_id),
        )
        conn.commit()
    else:
        # Insert a new record if the discordid doesn't exist

        c.execute(
            "INSERT INTO blacklistedWords (discordid, words) VALUES (?, ?)",
            (server_id, normalized_word),
        )
        conn.commit()
    conn.close()


class CookieClickerGame:
    def __init__(self):
        self.cookies = 0
        self.click_multiplier = 1
        self.cookie_production = 1
        self.upgrade_cost_multiplier = 1.2
        self.upgrade_cost_exponent = 1.5
        self.active_events = set()

    def click_cookie(self):
        self.cookies += self.click_multiplier

    def auto_cookie_production(self):
        self.cookies += self.cookie_production

    def get_cookies(self):
        return self.cookies

    def save_cookies(self, user_id):
        cursor.execute(
            "INSERT OR REPLACE INTO cookies (user_id, cookies) VALUES (?, ?)",
            (user_id, self.cookies),
        )
        conn.commit()

    def load_cookies(self, user_id):
        cursor.execute("SELECT cookies FROM cookies WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        if result:
            self.cookies = result[0]

    def purchase_upgrade(self):
        upgrade_cost = int(
            10
            * (
                self.upgrade_cost_multiplier
                ** (self.click_multiplier**self.upgrade_cost_exponent)
            )
        )
        if self.cookies >= upgrade_cost:
            self.cookies -= upgrade_cost
            self.click_multiplier *= 2
            self.upgrade_cost_multiplier += 0.1
            return True
        return False

    def activate_random_event(self):
        event_chance = random.randint(1, 100)
        if (
            event_chance <= 15 and not self.active_events
        ):  # 15% chance of a random event, only one event at a time
            event_type = random.choice(
                ["Double Cookies", "Cookie Rain", "Cookie Thief"]
            )
            self.active_events.add(event_type)
            return event_type
        return None

    def handle_event(self, event_type):
        if event_type == "Double Cookies":
            self.click_multiplier *= 2
        elif event_type == "Cookie Rain":
            self.cookie_production *= 2
        elif event_type == "Cookie Thief":
            stolen_cookies = min(self.cookies, random.randint(20, 50))
            self.cookies -= stolen_cookies
            return stolen_cookies
        return 0

    def deactivate_event(self, event_type):
        self.active_events.discard(event_type)


game = CookieClickerGame()
cookie_messages = {}  # Dictionary to store cookie_msg for each user


async def cookie_clicker_loop():
    await client.wait_until_ready()
    while not client.is_closed():
        game.click_cookie()
        game.auto_cookie_production()
        event_type = game.activate_random_event()
        if event_type:
            await asyncio.sleep(5)  # Wait for 5 seconds to simulate an event delay
            stolen_cookies = game.handle_event(event_type)
            if event_type == "Cookie Thief":
                await client.get_channel(YOUR_CHANNEL_ID).send(
                    f"Cookie Thief Event: A thief stole {stolen_cookies} cookies!"
                )
            else:
                await client.get_channel(YOUR_CHANNEL_ID).send(
                    f"{event_type} Event: {event_type} is active for a limited time!"
                )
            game.deactivate_event(event_type)
        await asyncio.sleep(1)


async def update_cookie_embed(message, embed):
    user_id = message.author.id
    game.load_cookies(user_id)
    embed.description = f"Total Cookies: {game.get_cookies()}\nClick Value: {game.click_multiplier} cookies\nCookie Production: {game.cookie_production} cookies/s"

    if user_id in cookie_messages:
        await cookie_messages[user_id].edit(embed=embed)
    else:
        msg = await message.channel.send(embed=embed)
        await msg.add_reaction("🍪")  # Click cookie reaction
        await msg.add_reaction("🛒")  # Upgrade purchase reaction
        cookie_messages[user_id] = msg

    def check(reaction, user):
        return (
            user == message.author
            and str(reaction.emoji) in ["🍪", "🛒"]
            and reaction.message.id == cookie_messages[user_id].id
        )

    try:
        reaction, user = await client.wait_for(
            "reaction_add", timeout=60.0, check=check
        )
        if str(reaction.emoji) == "🍪":
            game.click_cookie()
            game.save_cookies(user.id)
            await update_cookie_embed(message, embed)
        elif str(reaction.emoji) == "🛒":
            game.load_cookies(user.id)
            if game.purchase_upgrade():
                game.save_cookies(user.id)
                await update_cookie_embed(message, embed)
            else:
                await message.channel.send(
                    f"{user.mention}, you don't have enough cookies to purchase an upgrade."
                )
                await update_cookie_embed(message, embed)
    except asyncio.TimeoutError:
        await message.channel.send(
            "Reaction time expired. Run the command again to continue."
        )


# Function to remove a word from the blacklist for a specific server


def remove_blacklisted_word(server_id, word):
    conn = sqlite3.connect("bot.sql")
    c = conn.cursor()

    # Get the current blacklisted words for the server

    current_words = c.execute(
        "SELECT words FROM blacklistedWords WHERE discordid=?", (server_id,)
    ).fetchone()

    if current_words:
        # Split and strip each word

        words = [w.strip() for w in current_words[0].split(",")]

        # Remove the specified word

        words = [w for w in words if w != word.strip()]

        # Join the remaining words back into a single string

        updated_words = ", ".join(words)

        # Update the existing record with the modified words

        c.execute(
            "UPDATE blacklistedWords SET words=? WHERE discordid=?",
            (updated_words, server_id),
        )
        conn.commit()
    conn.close()


# Function to clear all blacklisted words for a specific server


async def generate_qrcode(msg, channel):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(msg)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    img.save("qrcode.png")
    channel = client.get_channel(channel)
    await channel.send(file=discord.File("qrcode.png"))


def clear_blacklisted_words(server_id):
    conn = sqlite3.connect("bot.sql")
    c = conn.cursor()
    c.execute("DELETE FROM blacklistedWords WHERE discordid=?", (server_id,))
    conn.commit()


async def check_blacklisted_words(message):
    server_id = message.guild.id
    content_lower = message.content.lower()
    blacklisted_words = get_blacklisted_words(server_id)

    for word in blacklisted_words:
        if contains_word(content_lower, word.lower()):
            await message.delete()
            await message.channel.send(
                f"{message.author.mention}, your message contains a blacklisted word and has been removed."
            )


def get_blacklisted_words(server_id):
    conn = sqlite3.connect("bot.sql")
    c = conn.cursor()
    c.execute("SELECT words FROM blacklistedWords WHERE discordid=?", (server_id,))
    result = c.fetchall()
    words = [
        w.strip() for row in result for w in row[0].split(",")
    ]  # Split and strip each word
    return words


async def my_background_task():
    await client.wait_until_ready()  # ensures cache is loaded
    counter = 0  # replace with target channel id
    while not client.is_closed():
        counter += 1
        await asyncio.sleep(6000)  # or 300 if you wish for it to be 5 minutes


# Function to set the channel ID in the database


def set_channel_id(discord_id, channel_id):
    conn = sqlite3.connect("bot.sql")
    c = conn.cursor()
    c.execute(
        "INSERT OR REPLACE INTO discord (id, channel) VALUES (?, ?)",
        (discord_id, channel_id),
    )
    conn.commit()


# Function to set the channel ID in the database


def set_botchannel_id(discord_id, channel_id):
    conn = sqlite3.connect("bot.sql")
    c = conn.cursor()
    c.execute(
        "INSERT OR REPLACE INTO botchan (id, channel) VALUES (?, ?)",
        (discord_id, channel_id),
    )
    conn.commit()


@client.event
async def on_guild_remove(guild: discord.Guild):
    conn = sqlite3.connect("bot.sql")
    c = conn.cursor()
    c.execute("DELETE FROM discord WHERE id = ?", (guild.id,))
    conn.commit()


def contains_word(message_content, word):
    return f" {word.lower()} " in f" {message_content.lower()} "


def nomArgs(args):
    return len(args.split())


def contains_word(s, w):
    return (" " + w + " ") in (" " + s + " ")


def translate(sentance):
    return translator.translate(sentance, dest="en").text


def urlShort(url):
    typetiny = pyshorteners.Shortener()
    shorturl = typetiny.tinyurl.short(url)
    return shorturl


def getJoke():
    url = "https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,racist,sexist,explicit"

    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers)

    return response.text


@client.event
async def on_message_delete(message):
    if message.author == client.user:
        return
    else:
        if (
            message.content.startswith("nkl")
            or message.content.startswith("Nkl")
            or message.content.startswith("Nklpg")
            or message.content.startswith("nklpg")
            or message.content.startswith("Nkldond")
            or message.content.startswith("nkldond")
        ):
            return
        else:
            delChannel = get_channel_id(message.guild.id)
            if delChannel:
                now = datetime.datetime.now()
                # check logs to see who deleted it

                after = now - datetime.timedelta(minutes=1)
                usr = message.author
                channel = client.get_channel(delChannel)
                delChannel = get_channel_id(message.guild.id)
                channel = client.get_channel(delChannel)
                async for entry in message.guild.audit_logs(
                    limit=1, action=discord.AuditLogAction.message_delete
                ):
                    if entry.created_at.replace(tzinfo=None) > after.replace(
                        tzinfo=None
                    ):
                        is_blacklisted_msg = await is_blacklisted_word(message)
                        if is_blacklisted_msg is True:
                            deleter = entry.user
                            delChannel = get_channel_id(message.guild.id)
                            channel = client.get_channel(delChannel)
                            embed = discord.Embed(
                                title="Deleted Message",
                                description=message.content,
                                colour=0xF50000,
                                timestamp=datetime.datetime.utcnow(),
                            )
                            embed.set_author(name=deleter.name, url="")
                            embed.set_footer(
                                text="By: "
                                + message.author.name
                                + " in "
                                + message.channel.name,
                                icon_url=message.author.avatar,
                            )
                            if message.attachments:
                                embed.set_image(url=message.attachments[0].url)
                            await channel.send(embed=embed)
                        else:
                            deleter = entry.user
                            delChannel = get_channel_id(message.guild.id)
                            channel = client.get_channel(delChannel)
                            embed = discord.Embed(
                                title="Deleted Message",
                                description=message.content,
                                colour=0xF50000,
                                timestamp=datetime.datetime.utcnow(),
                            )
                            embed.set_author(name="Nookle Moderation", url="")
                            embed.set_footer(
                                text="By: "
                                + message.author.name
                                + " in "
                                + message.channel.name,
                                icon_url=message.author.avatar,
                            )
                            if message.attachments:
                                embed.set_image(url=message.attachments[0].url)
                            await channel.send(embed=embed)
                    else:
                        is_blacklisted_msg = await is_blacklisted_word(message)
                        if is_blacklisted_msg is True:
                            delChannel = get_channel_id(message.guild.id)
                            channel = client.get_channel(delChannel)
                            embed = discord.Embed(
                                title="Censored Message",
                                description=message.content,
                                colour=0xF50000,
                                timestamp=datetime.datetime.utcnow(),
                            )
                            embed.set_author(name="Nookle Moderation", url="")
                            embed.set_footer(
                                text="By: "
                                + message.author.name
                                + " in "
                                + message.channel.name,
                                icon_url=message.author.avatar,
                            )
                            if message.attachments:
                                embed.set_image(url=message.attachments[0].url)
                            await channel.send(embed=embed)
                        else:
                            delChannel = get_channel_id(message.guild.id)
                            channel = client.get_channel(delChannel)
                            embed = discord.Embed(
                                title="Deleted Message",
                                description=message.content,
                                colour=0xF50000,
                                timestamp=datetime.datetime.utcnow(),
                            )
                            embed.set_author(name=message.author.name, url="")
                            embed.set_footer(
                                text="By: "
                                + message.author.name
                                + " in "
                                + message.channel.name,
                                icon_url=message.author.avatar,
                            )
                            if message.attachments:
                                embed.set_image(url=message.attachments[0].url)
                            await channel.send(embed=embed)


def getDefinitions(word):
    url = "https://api.dictionaryapi.dev/api/v2/entries/en/" + word

    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers)

    info = json.loads(response.text)
    if isinstance(info, list) and info:
        if "meanings" in info[0] and info[0]["meanings"]:
            if (
                "definitions" in info[0]["meanings"][0]
                and info[0]["meanings"][0]["definitions"]
            ):
                theDef = info[0]["meanings"][0]["definitions"][0]["definition"]
                return theDef
    return "Could not retrieve definition"


async def deal_game(player_id, message):
    prizes = [1, 5, 10, 25, 50, 75, 100, 200, 300, 400, 500, 750, 1000]
    random.shuffle(prizes)
    chosen_prize_index = random.randint(0, len(prizes) - 1)
    chosen_prize = prizes.pop(chosen_prize_index)

    remaining_crates = list(range(1, 13))

    player_crates = []

    # Create an embed for the values

    embed_values = discord.Embed(
        title="Deal or No Deal",
        description="Here are the values you can get:",
        color=0x00FF00,
    )
    embed_values.add_field(name="Available Values", value=", ".join(map(str, prizes)))

    await message.channel.send(embed=embed_values)

    while len(remaining_crates) > 2:
        # Create an embed for the remaining crates

        embed_remaining_crates = discord.Embed(
            title="Deal or No Deal",
            description=f"Remaining crates: {remaining_crates}\nChoose a crate by typing the number.",
            color=0x00FF00,
        )
        await message.channel.send(embed=embed_remaining_crates)

        def check(m):
            return (
                m.author == message.author
                and m.content.isdigit()
                and int(m.content) in remaining_crates
            )

        try:
            response = await client.wait_for("message", check=check, timeout=30)
            chosen_crate = int(response.content)
            remaining_crates.remove(chosen_crate)

            try:
                removed_value = prizes.pop(random.choice(range(len(prizes))))
            except (ValueError, IndexError):
                await message.channel.send(
                    "An error occurred while processing your choice. Please try again."
                )
                return
            player_crates.append(chosen_crate)

            # Create an embed for the removed value

            embed_removed_value = discord.Embed(
                title="Deal or No Deal",
                description=f"The value {removed_value} has been removed from what you can get.",
                color=0x00FF00,
            )
            await message.channel.send(embed=embed_removed_value)
        except asyncio.TimeoutError:
            await message.channel.send("Time's up! Game over.")
            return
        if len(player_crates) % 3 == 0:
            banker_offer = calculate_banker_offer(prizes)
            # Create an embed for the banker offer

            embed_banker_offer = discord.Embed(
                title="Deal or No Deal",
                description=f"The banker offers you {banker_offer} coins. Deal or No Deal? (type `deal` or `nodeal`)",
                color=0x00FF00,
            )
            await message.channel.send(embed=embed_banker_offer)

            response = await client.wait_for(
                "message",
                check=lambda m: m.author == message.author
                and m.content.lower() in ["deal", "nodeal"],
                timeout=30,
            )
            if response.content.lower() == "deal":
                # Create an embed for the final result

                embed_final_result = discord.Embed(
                    title="Deal or No Deal",
                    description=f"Congratulations! You accepted the banker's offer. You won {banker_offer} coins!",
                    color=0x00FF00,
                )
                await message.channel.send(embed=embed_final_result)
                playing_players.remove(player_id)
                return
    # Create an embed for the final crates

    embed_final_crates = discord.Embed(
        title="Deal or No Deal",
        description="Only two crates remaining. Choose between them.",
        color=0x00FF00,
    )
    embed_final_crates.add_field(
        name="Remaining Crates", value=", ".join(map(str, remaining_crates))
    )
    await message.channel.send(embed=embed_final_crates)

    # Force the player to choose between the last two crates

    await message.channel.send(f"Remaining crates: {remaining_crates}")
    await message.channel.send("Choose a crate by typing the number.")
    response = await client.wait_for("message", check=check, timeout=30)
    chosen_crate = int(response.content)
    remaining_crates.remove(chosen_crate)
    player_crates.append(chosen_crate)

    final_crate = remaining_crates[0]

    # Create an embed for the final result

    embed_final_result = discord.Embed(
        title="Deal or No Deal",
        description=f"You chose crate {chosen_crate}. Let's hear the banker's final offer...",
        color=0x00FF00,
    )
    await message.channel.send(embed=embed_final_result)
    await asyncio.sleep(2)  # Simulate a brief delay before revealing the final prize

    banker_final_offer = calculate_banker_offer(prizes)

    # Create an embed for the banker's final offer

    embed_final_offer = discord.Embed(
        title="Deal or No Deal",
        description=f"The banker's final offer is {banker_final_offer} coins. Deal or No Deal? (type `deal` or `nodeal`)",
        color=0x00FF00,
    )
    await message.channel.send(embed=embed_final_offer)

    response = await client.wait_for(
        "message",
        check=lambda m: m.author == message.author
        and m.content.lower() in ["deal", "nodeal"],
        timeout=30,
    )

    if response.content.lower() == "deal":
        # Create an embed for the final result

        embed_final_result = discord.Embed(
            title="Deal or No Deal",
            description=f"Congratulations! You accepted the banker's final offer. You won {banker_final_offer} coins!",
            color=0x00FF00,
        )
        await message.channel.send(embed=embed_final_result)
    else:
        if chosen_prize > banker_final_offer:
            # Create an embed for the final result

            embed_final_result = discord.Embed(
                title="Deal or No Deal",
                description=f"You chose to reject the final offer. Your initial choice of crate {chosen_crate} contained {chosen_prize} coins. Well done, you beat the banker!",
                color=0x00FF00,
            )
            await message.channel.send(embed=embed_final_result)
            playing_players.remove(player_id)
        else:
            # Create an embed for the final result

            embed_final_result = discord.Embed(
                title="Deal or No Deal",
                description=f"You chose to reject the final offer. Your initial choice of crate {chosen_crate} contained {chosen_prize} coins. Better luck next time!",
                color=0x00FF00,
            )
            await message.channel.send(embed=embed_final_result)
            playing_players.remove(player_id)


def calculate_banker_offer(prizes):
    return sum(prizes) // len(prizes)


async def send_lyrics_embed(embed, message, msg=None):
    if msg:
        await msg.edit(embed=embed)
    else:
        msg = await message.channel.send(embed=embed)
        await msg.add_reaction("⬅️")
        await msg.add_reaction("➡️")

    def check(reaction, user):
        return user == message.author and reaction.message.id == msg.id

    try:
        reaction, user = await client.wait_for(
            "reaction_add", timeout=60.0, check=check
        )
        return str(reaction.emoji), msg
    except:
        return None, msg


async def send_lyrics(song, message):
    max_lines = 10  # Set the maximum number of lines per message

    lyrics = song.lyrics.split("\n")
    num_verses = (len(lyrics) + max_lines - 1) // max_lines
    current_page = 0

    msg = None

    while current_page < num_verses:
        start_idx = current_page * max_lines
        end_idx = start_idx + max_lines
        current_lyrics = lyrics[start_idx:end_idx]

        lyrics_text = "\n\n".join(current_lyrics)
        embed = discord.Embed(
            title=f"Lyrics for {song.title} by {song.artist}",
            description=lyrics_text,
            color=discord.Color.blue(),
        )

        if current_page > 0:
            embed.set_footer(text=f"Page {current_page + 1}/{num_verses}")
        reaction, msg = await send_lyrics_embed(embed, message, msg)

        if reaction == "⬅️" and current_page > 0:
            current_page -= 1
        elif reaction == "➡️" and current_page < num_verses - 1:
            current_page += 1
        else:
            break


def getMeme():
    num = random.randint(0, 9)
    redit = [
        "dankmemes",
        "wholesomememes",
        "ProgrammerHumor",
        "PrequelMemes",
        "youtubehaiku",
        "ComedyCemetery",
        "terriblefacebookmemes",
        "funny",
        "memes",
        "comedymemes",
    ]
    reddit = redit[num]
    url = "https://meme-api.com/gimme/" + reddit + "/"

    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers)
    info = json.loads(response.text)
    if "url" in info:
        meme = info["url"]
        return meme
    else:
        return "Failed to get meme from reddit"


async def start_trivia_game(message):
    embed = discord.Embed(
        title="Trivia Quiz Setup",
        description="Let's set up a Trivia Quiz! Please choose the category, difficulty, and number of questions.",
        color=0x00FF00,
    )
    embed.add_field(
        name="Example",
        value="Enter Category (General Knowledge, Books, Film, Music, Musicals & Theatres, Television, Video Games, Board Games, Science & Nature, Computers, Gadgets, Nature, General, Mathematics, Mythology, Sports, Geography, History, Politics, Art, Celebrities, Animals, Vehicles, Comics, Anime & Manga, Cartoons)\n\n``Gadgets``\n\nEnter Difficulty (Easy, Medium, Hard)\n\nEasy\n\nNumber Of Questions\n\n8",
        inline=False,
    )
    await message.channel.send(embed=embed)

    def trivia_check(m):
        return m.author == message.author and m.channel == message.channel

    try:
        await message.channel.send("Enter the category:")
        category = await client.wait_for("message", timeout=30, check=trivia_check)
        await message.channel.send("Enter the difficulty:")
        difficulty = await client.wait_for("message", timeout=30, check=trivia_check)
        await message.channel.send("Enter the number of questions:")
        num_questions = await client.wait_for("message", timeout=30, check=trivia_check)

        category = category.content.strip()
        difficulty = difficulty.content.strip().lower()
        num_questions = int(num_questions.content.strip())

        questions = fetch_trivia_questions(category, difficulty, num_questions)
        if not questions:
            await message.channel.send(
                "Unable to fetch trivia questions. Please try again later."
            )
            return
        game_states[message.guild.id] = {
            "questions": questions,
            "current_question_index": 0,
            "player_scores": {},
        }

        await ask_trivia_question(message)
    except asyncio.TimeoutError:
        await message.channel.send("Setup timed out. Please start again.")


async def ask_trivia_question(message):
    guild_id = message.guild.id
    game_state = game_states[guild_id]

    if game_state["current_question_index"] < len(game_state["questions"]):
        question = game_state["questions"][game_state["current_question_index"]]
        formatted_question = format_trivia_question(question)

        embed = discord.Embed(
            title=f"Question {game_state['current_question_index'] + 1}",
            description=formatted_question,
            color=0x00FF00,
        )
        await message.channel.send(embed=embed)

        def trivia_check(m):
            return m.author == message.author and m.channel == message.channel

        try:
            response = await client.wait_for("message", timeout=30, check=trivia_check)
            await handle_trivia_answer(response, message)
        except asyncio.TimeoutError:
            await message.channel.send("Time's up! Moving to the next question.")
            await move_to_next_question(message)
    else:
        await end_trivia_game(message)


async def handle_trivia_answer(response, message):
    # Handle the user's answer here
    # You can compare the answer to the correct answer and update scores

    # For example, checking if the answer is correct

    guild_id = message.guild.id
    game_state = game_states[guild_id]
    question = game_state["questions"][game_state["current_question_index"]]
    correct_answer = html.unescape(question["correct_answer"]).lower()

    if response.content.lower() == correct_answer:
        await message.channel.send("Correct answer! You earned a point.")
        user_id = response.author.id
        if user_id in game_state["player_scores"]:
            game_state["player_scores"][user_id] += 1
        else:
            game_state["player_scores"][user_id] = 1
    else:
        await message.channel.send(
            f"Wrong answer! The correct answer was: {correct_answer}"
        )
    await move_to_next_question(message)


async def move_to_next_question(message):
    guild_id = message.guild.id
    game_state = game_states[guild_id]
    game_state["current_question_index"] += 1
    await ask_trivia_question(message)


def fetch_trivia_questions(category, difficulty, num_questions):
    category_mapping = {
        "General Knowledge": 9,
        "Books": 10,
        "Film": 11,
        "Music": 12,
        "Musicals & Theatres": 13,
        "Television": 14,
        "Video Games": 15,
        "Board Games": 16,
        "Science & Nature": 17,
        "Computers": 18,
        "Gadgets": 30,
        "Nature": 17,
        "Science: Computers": 18,
        "Science: Gadgets": 30,
        "Science: General": 24,
        "Mathematics": 19,
        "Mythology": 20,
        "Sports": 21,
        "Geography": 22,
        "History": 23,
        "Politics": 24,
        "Art": 25,
        "Celebrities": 26,
        "Animals": 27,
        "Vehicles": 28,
        "Cartoons": 32,
        "Anime & Manga": 31,
        "Comics": 29,
        "Entertainment: Comics": 29,
        "Entertainment: Anime & Manga": 31,
        "Entertainment: Cartoons": 32,
    }

    if category not in category_mapping:
        print(f"Invalid category: {category}")
        return None
    params = {
        "amount": num_questions,
        "category": category_mapping[category],
        "difficulty": difficulty,
        "type": "multiple",
    }

    api_url = "https://opentdb.com/api.php"
    response = requests.get(api_url, params=params)

    print(f"Fetching trivia questions from: {response.url}")

    if response.status_code == 200:
        return response.json()["results"]
    else:
        print(f"Failed to fetch trivia questions. Status code: {response.status_code}")
        return None


async def help_command(message):
    embeds = [
        discord.Embed(
            title="Setup",
            description="> nkl setBotChannel {channel ID}\nThis will be the only place commands can be run with this bot\n\n> nkl delMessChannel {channel ID}\nThis will log deleted messages into the given channel",
            colour=0x7A00F5,
            timestamp=datetime.datetime.utcnow(),
        ).set_footer(text=f"I am in {len(client.guilds)} servers!"),
        discord.Embed(
            title="General",
            description="> Nkl shurl {url}\nThis shortens a url\n\n> nkl qrcreate {link}\n Generate a qrcode\n\n> nkl\nShows the main help page.\n\n[Invite Me](https://discord.com/api/oauth2/authorize?client_id=1186662197582114886&permissions=8&scope=bot)",
            colour=0x7A00F5,
            timestamp=datetime.datetime.utcnow(),
        ).set_footer(text=f"I am in {len(client.guilds)} servers!"),
        # ... (Other help embeds in the desired order)
        discord.Embed(
            title="Info",
            description="> nkl\nThis shows the help page\n\n> nkl def {word}\nThis shows you the definition of a word\n\n> nkl tl {words}\nGoogle Translate something to English\n\n> nkl lyrics {song}\nGet a song's lyrics\n\n> nkl lyrics {song} artist {name}\nPlay an artist's variation of a song\n\n> nkl anime (title)\nGet information on an anime\n\n> nkl devlog\nGet info on the recent updates",
            colour=0x7A00F5,
            timestamp=datetime.datetime.utcnow(),
        ).set_footer(text=f"I am in {len(client.guilds)} servers!"),
        discord.Embed(
            title="Fun",
            description="> nkl joke\nThis tells you a joke\n\n> nkl joke2p\nThis tells you a two-part joke\n\n> nkl meme\nThis posts a random meme from Reddit (filtered)",
            colour=0x7A00F5,
            timestamp=datetime.datetime.utcnow(),
        ).set_footer(text=f"I am in {len(client.guilds)} servers!"),
        discord.Embed(
            title="Games",
            description="> Nkl dond\nIt's time to play Deal Or No Deal\n\n> nkl trivia\nPlay a trivia game\n\n> nkl cc\nPlay a simplified cookie clicker",
            colour=0x7A00F5,
            timestamp=datetime.datetime.utcnow(),
        ).set_footer(text=f"I am in {len(client.guilds)} servers!"),
        discord.Embed(
            title="Moderation",
            description="> nkl delMessChannel {channel ID}\nThis will log deleted messages into the given channel\n\n> nkl addbadword {word}\nThis will add to the blacklisted words\n\n> nkl removebadword {word}\nRemoves a bad word from the blacklist\n\n> nkl clearbadwords\nThis will clear the blacklisted words\n\n> nkl badwords\nThis will list the blacklisted words",
            colour=0x7A00F5,
            timestamp=datetime.datetime.utcnow(),
        ).set_footer(text=f"I am in {len(client.guilds)} servers!"),
    ]

    current_page = 0

    help_message = await message.channel.send(embed=embeds[current_page])
    await help_message.add_reaction("⬅️")
    await help_message.add_reaction("➡️")

    def check(reaction, user):
        return user == message.author and str(reaction.emoji) in ["⬅️", "➡️"]

    while True:
        try:
            reaction, _ = await client.wait_for(
                "reaction_add", timeout=60.0, check=check
            )

            if str(reaction.emoji) == "➡️" and current_page < len(embeds) - 1:
                current_page += 1
            elif str(reaction.emoji) == "⬅️" and current_page > 0:
                current_page -= 1
            await help_message.edit(embed=embeds[current_page])
            await help_message.remove_reaction(reaction, message.author)
        except TimeoutError:
            break


@client.event
async def on_ready():
    await client.change_presence(activity=discord.Game("nkl - To view the help page"))
    print("We have logged in as {0.user}".format(client))
    client.loop.create_task(my_background_task())  # best to put it in here


@client.event
async def on_message(message):
    global dondgame_active

    if message.author == client.user:
        return
    await check_blacklisted_words(message)
    is_blacklisted_msg = await is_blacklisted_word(message)
    botchanid = get_botchannel_id(message.guild.id)
    
    if not message.guild.me.guild_permissions.manage_messages and message.content.startswith('nkl'):
        await message.channel.send("I don't have the required permissions to delete messages which i need to delete command messages and censor messages.")
        return
    if not message.guild.me.guild_permissions.manage_messages and message.content.startswith('Nkl'):
        await message.channel.send("I don't have the required permissions to delete messages which i need to delete command messages and censor messages.")
        return

    if (
        message.content.startswith("nkl")
        or message.content.startswith("Nkl")
        and message.author.id not in playing_players
    ):
        if message.channel.id == botchanid or botchanid is False or message.author.guild_permissions.administrator:
            if contains_word(message.content, "dab"):
                await message.delete()
                await message.channel.send("No")
            elif contains_word(message.content, "dond"):
                if not dondgame_active:
                    playing_players.add(message.author.id)
                    await message.channel.send(
                        "Welcome to Deal or No Deal! Let's get started."
                    )
                    await deal_game(message.author.id, message)
                    dondgame_active = False
                else:
                    await message.channel.send(
                        "A game is already in progress. Finish the current game before starting a new one."
                    )
            elif contains_word(message.content, "meme"):
                await message.delete()
                await message.channel.send(getMeme())
            elif contains_word(message.content, "trivia"):
                await message.delete()
                await start_trivia_game(message)
            elif contains_word(message.content, "delMessChannel"):
                if message.author.guild_permissions.administrator:
                    if not message.guild.me.guild_permissions.view_audit_log:
                        s = message.content
                        st = s.split(" ", 2)
                        set_botchannel_id(message.guild.id, st[2])
                        await message.delete()
                        await message.channel.send("Channel set!")
                    else:
                        await message.delete()
                        await message.channel.send("Required view_audit_log permissions for the best accuracy.!")
                else:
                    await message.delete()
                    await message.channel.send(
                        "You do not have permission to use this command"
                    )
            elif contains_word(message.content, "setBotChannel"):
                if message.author.guild_permissions.administrator:
                    s = message.content
                    st = s.split(" ", 2)
                    set_botchannel_id(message.guild.id, st[2])
                    await message.delete()
                    await message.channel.send("Channel set!")
                else:
                    await message.delete()
                    await message.channel.send(
                        "You do not have permission to use this command"
                    )
            elif contains_word(message.content, "badwords"):
                server_id = message.guild.id
                blacklisted_words = get_blacklisted_words(server_id)
                if message.author.guild_permissions.administrator:
                    embed = discord.Embed(
                        title="Current list of blacklisted words for this server",
                        color=0xFF0000,
                    )
                    for word in blacklisted_words:
                        embed.add_field(
                            name="Blacklisted Word", value=word, inline=False
                        )
                    await message.delete()
                    await message.channel.send(embed=embed)
                else:
                    await message.delete()
                    await message.channel.send(
                        "You do not have permission to use this command"
                    )
            elif contains_word(message.content, "addbadword"):
                if message.author.guild_permissions.administrator:
                    server_id = message.guild.id
                    s = message.content
                    st = s.split(" ", 2)
                    if is_blacklisted_msg:
                        await message.delete()
                        await message.channel.send(f"That word is already blacklisted.")
                    else:
                        add_blacklisted_word(server_id, st[2])
                        await message.delete()
                        await message.channel.send(f"Word added to the blacklist.")
                else:
                    await message.delete()
                    await message.channel.send(
                        "You do not have permission to use this command."
                    )
            elif contains_word(message.content, "removebadword"):
                if message.author.guild_permissions.administrator:
                    server_id = message.guild.id
                    s = message.content
                    st = s.split(" ", 2)
                    if is_blacklisted_msg:
                        remove_blacklisted_word(server_id, st[2])
                        await message.channel.send(f"Word removed from the blacklist.")
                    else:
                        await message.delete()
                        await message.channel.send(
                            f"Word '{st[2]}' wasn't blacklisted."
                        )
                else:
                    await message.delete()
                    await message.channel.send(
                        "You do not have permission to use this command."
                    )
            elif contains_word(message.content, "clearbadwords"):
                if message.author.guild_permissions.administrator:
                    server_id = message.guild.id
                    clear_blacklisted_words(server_id)
                    await message.delete()
                    await message.channel.send("All blacklisted words cleared.")
                else:
                    await message.delete()
                    await message.channel.send(
                        "You do not have permission to use this command."
                    )
            elif contains_word(message.content, "shurl"):
                s = message.content
                st = s.split(" ", 2)
                await message.delete()
                await message.channel.send(urlShort(st[2]))
            elif contains_word(message.content, "def"):
                s = message.content
                st = s.split(" ", 2)
                await message.delete()
                await message.channel.send(getDefinitions(st[2]))
            elif contains_word(message.content, "qrcreate"):
                s = message.content
                st = s.split(" ", 2)
                a = message.channel.id
                await message.delete()
                try:
                    await generate_qrcode(st[2], a)
                except:
                    await message.channel.send("Link Error")
            elif contains_word(message.content, "tl"):
                s = message.content
                st = s.split(" ", 2)
                await message.delete()
                await message.channel.send(translate(st[2]))
            elif contains_word(message.content, "devlog"):
                await message.delete()
                embed=discord.Embed(title="Latest Updates", url="https://realdrewdata.medium.com/", description="Admins can now use the bot without being restricted to a channel\n\nYou can now create qr codes\n> nkl qrcreate (link)\n\n> anime {title}\nGet information on an anime", color=0xFF5733)
                embed.set_author(name="Nookle | Devlog", url="https://example.com")
                await message.channel.send(embed=embed)
            elif contains_word(message.content, "cc"):
                await message.delete()
                embed = discord.Embed(
                    title="Cookie Clicker",
                    description="Initializing...",
                    color=0x00FF00,
                )
                embed.set_footer(
                    text="React with 🍪 to click the cookie or 🛒 to purchase an upgrade."
                )
                await update_cookie_embed(message, embed)
            elif contains_word(message.content, "lyrics"):
                await message.delete()
                try:
                    if contains_word(message.content, "artist"):
                        stt = message.content.split(" ", 2)[
                            2
                        ]  # Split into three parts to correctly extract artist and song
                        mystring = message.content
                        keyword = "artist"
                        before_keyword, keyword, after_keyword = stt.partition(keyword)
                        genius = lyricsgenius.Genius(
                            "y8o0CacWNagGir39Oh-21mfm2cau5kH7FZobksISdCW8K8SkmtEJDmKqxZRtI_dc"
                        )
                        artist = after_keyword
                        song_title = before_keyword
                        if artist:
                            song = genius.search_song(song_title, artist)
                            if song:
                                await send_lyrics(song, message)
                            else:
                                await message.channel.send(
                                    f'No version of "{song_title}" found for artist: {artist_name}'
                                )
                        else:
                            await message.channel.send(f"Unknown artist: {artist_name}")
                    else:
                        song_title = message.content.split(" ", 2)[2]
                        genius = lyricsgenius.Genius(
                            "y8o0CacWNagGir39Oh-21mfm2cau5kH7FZobksISdCW8K8SkmtEJDmKqxZRtI_dc"
                        )
                        song = genius.search_song(song_title)
                        if song:
                            await send_lyrics(song, message)
                        else:
                            await message.channel.send(
                                f'Lyrics for "{song_title}" not found on Genius.'
                            )
                except Exception as e:
                    print(e)
                    await message.channel.send("Error fetching lyrics.")
            elif contains_word(message.content, "joke"):
                url = "https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,racist,sexist,explicit&type=single"
                headers = {"Content-Type": "application/json"}
                response = requests.request("GET", url, headers=headers)
                info = json.loads(response.text)
                joke = info["joke"]
                await message.delete()
                await message.channel.send(joke)
            elif contains_word(message.content, "joke2p"):
                url = "https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,racist,sexist,explicit&type=twopart"
                headers = {"Content-Type": "application/json"}
                response = requests.request("GET", url, headers=headers)
                info = json.loads(response.text)
                setups = info["setup"]
                punchlines = info["delivery"]
                connec = "> " + setups + "\n" + "> " + punchlines
                await message.delete()
                await message.channel.send(connec)
            elif contains_word(message.content, "vote"):
                embed = discord.Embed(
                    title="Voting",
                    description="> [Vote for Nookle](http://www.google.com)",
                    colour=0x7A00F5,
                    timestamp=datetime.datetime.utcnow(),
                )
                embed.set_author(name="Nookle | Help", url="https://example.com")
                embed.set_footer(
                    text="Nookle",
                    icon_url="https://i.ibb.co/3M6p7z0/0150f920-9f9a-4910-80cc-e1204a1fdde8.jpg",
                )
                await message.delete()
                await message.channel.send(embed=embed)
            elif contains_word(message.content, "anime"):
                s = message.content
                st = s.split(" ", 2)
                anime_title = st[2]
                
                # Step 1: Search for the anime to get its ID
                search_url = f"https://api.jikan.moe/v4/anime?q={anime_title}&limit=1"
                try:
                    search_response = requests.get(search_url)
                    search_response.raise_for_status()  # Check for HTTP errors
                    search_data = search_response.json()
                    
                    if "data" in search_data and search_data["data"]:
                        anime_id = search_data["data"][0]["mal_id"]
                        
                        # Step 2: Fetch full details using the ID
                        full_url = f"https://api.jikan.moe/v4/anime/{anime_id}/full"
                        full_response = requests.get(full_url)
                        full_response.raise_for_status()  # Check for HTTP errors
                        full_data = full_response.json()
                        
                        if "data" in full_data and full_data["data"]:
                            anime_data = full_data["data"]
                            
                            title = anime_data.get("title", "N/A")
                            type = anime_data.get("type", "N/A")
                            episodes = anime_data.get("episodes", "N/A")
                            status = anime_data.get("status", "N/A")
                            airing = anime_data.get("airing", False)
                            synopsis = anime_data.get("synopsis", "N/A")
                            
                            # Get the image URL
                            image_url = (
                                anime_data.get("images", {})
                                .get("jpg", {})
                                .get("large_image_url", None)
                            )
                            
                            # Creating an embed
                            embed = discord.Embed(
                                title=title, description=synopsis, color=discord.Color.blue()
                            )
                            embed.add_field(name="Type", value=type, inline=True)
                            embed.add_field(name="Episodes", value=episodes, inline=True)
                            embed.add_field(name="Status", value=status, inline=True)
                            embed.add_field(name="Airing", value=airing, inline=True)
                            
                            # Add image to the embed
                            if image_url:
                                embed.set_thumbnail(url=image_url)
                                
                            await message.channel.send(embed=embed)
                            
                        else:
                            await message.channel.send(
                                f"No information found for {anime_title}."
                            )
                            
                    else:
                        await message.channel.send(f"No information found for {anime_title}.")
                        
                except requests.exceptions.HTTPError as errh:
                    print("HTTP Error:", errh)
                    await message.channel.send("Error fetching data from the Jikan API.")
                    
                except requests.exceptions.RequestException as err:
                    print("Error:", err)
                    await message.channel.send(
                        "An error occurred while processing the request."
                    )
            else:
                try:
                    await message.delete()
                    await help_command(message)
                except:
                    return
    else:
        if message.content.startswith("nkl") or message.content.startswith("Nkl"):
            if message.channel.id == botchanid or botchanid is False:
                if contains_word(message.content, "dond"):
                    await message.delete()
                    await message.channel.send(
                        "You are already playing Deal or No Deal."
                    )


client.run(" ")